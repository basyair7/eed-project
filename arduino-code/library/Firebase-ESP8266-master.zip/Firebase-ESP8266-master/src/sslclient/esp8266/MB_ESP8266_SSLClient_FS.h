#ifndef MB_ESP8266_SSLClient_FS_H
#define MB_ESP8266_SSLClient_FS_H
#include <Arduino.h>

#pragma once

// #define MB_ESP8266_SSLCLIENT_ENABLE_DEBUG

#endif